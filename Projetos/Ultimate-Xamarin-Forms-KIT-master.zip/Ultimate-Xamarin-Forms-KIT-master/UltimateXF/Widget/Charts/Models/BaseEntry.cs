﻿using System;
namespace UltimateXF.Widget.Charts.Models
{
    public abstract class BaseEntry
    {
        public BaseEntry()
        {
            
        }
    }
}
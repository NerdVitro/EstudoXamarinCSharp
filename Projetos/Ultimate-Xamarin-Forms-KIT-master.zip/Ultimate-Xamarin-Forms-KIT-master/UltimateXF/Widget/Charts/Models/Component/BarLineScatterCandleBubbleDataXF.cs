﻿using System;
namespace UltimateXF.Widget.Charts.Models.Component
{
    public abstract class BarLineScatterCandleBubbleDataXF
    {
        public BarLineScatterCandleBubbleDataXF()
        {
        }
    }
}

﻿using System;
namespace UltimateXF.Widget.Charts.Models.Component
{
    public interface IAxisValueFormatterXF
    {
        string GetFormattedValue(float _Value);
    }
}
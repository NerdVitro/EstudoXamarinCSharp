﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace UltimateXF.Widget.Charts.Models.ComponentXF
{
    public abstract class BaseDataXF : BindableObject 
    {
        
    }
}
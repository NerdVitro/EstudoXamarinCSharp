﻿using System;
namespace UltimateXF
{
    public interface IFont
    {
        string IF_GetDefaultFontFamily();
    }
}
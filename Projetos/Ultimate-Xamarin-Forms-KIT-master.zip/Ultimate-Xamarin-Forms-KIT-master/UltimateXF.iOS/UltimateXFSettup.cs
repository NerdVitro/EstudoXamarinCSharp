﻿using System;
namespace UltimateXF.iOS
{
    public static class UltimateXFSettup
    {
        public static void Initialize()
        {
        }
    }
}